# shellcheck shell=bash

# shellcheck source=src/usr/lib/rsetup/cli/test/gstreamer.sh
source "/usr/lib/rsetup/cli/test/gstreamer.sh"
source "/usr/lib/rsetup/cli/test/mpp.sh"
source "/usr/lib/rsetup/cli/test/stress.sh"
